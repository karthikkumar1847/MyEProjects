package GenericsEx;

import java.util.Date;

public class GenericsArraylist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d1 = new Date();
		Date d2 = new Date();
 		
		//String x = "HII";
		Object o = new String("HII");
		Object o2 = new Integer(5);
		
		System.out.println(d1.compareTo(d2));
	}

}
